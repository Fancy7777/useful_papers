/* Optional packages.  You might want to integrate this with your build system e.g. config.h from ./configure. */
#ifndef UTIL_HAVE_H
#define UTIL_HAVE_H

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#ifndef HAVE_ICU
//#define HAVE_ICU
#endif

#endif // UTIL_HAVE_H
