#ifndef UTIL_SPACES_H
#define UTIL_SPACES_H

// bool array of spaces.

namespace util {

extern const bool kSpaces[256];

} // namespace util

#endif // UTIL_SPACES_H
